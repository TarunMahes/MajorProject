<center>
		<footer>
		
		<p style="color:white;" >GITA AUTONOMOUS COLLEGE E-Learning Copyright 2023</p>
			<!-- <p>Programmed by: John Kevin Lorayna BSIS 4-A</p> -->
		</footer>
</center>

