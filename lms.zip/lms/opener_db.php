<?php
include("dbConnector.php"); 
$connector = new DbConnector();
?>