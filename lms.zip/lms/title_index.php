				<div style="margin-top:100px;">
								<div class="row-fluid">

						<div class="span12">
						
						</div>	
													
							</div>
							<div class="row-fluid">

						<div class="span4">
						<img class="index_logo" src="admin/images/gitalogo.jpg" style="border:round;">
						</div>	
						<div class="span8">
						
								<div class="title">
							<p style="color:white;" class="chmsc">Gandhi Institute for Technological Advancement - Bhubaneswar</p>
							<h3>

							<p>E - Learning</p>
						
							</h3>		
						</div>
			
						</div>							
							</div>
				
				<div class="row-fluid">

						<div class="span12">
						<br>
								<div class="motto">
												<p>GITA AUTONOMOUS COLLEGE:</p>
												<p>Tested, Selected and Initiated</p>
												<p>Learn Understand & Explore</p>
								</div>		
						</div>		
				</div>
		</div>